# Planetary Motion

![Alt](https://github.com/Soul-Snatcher/PatternGenerator/blob/master/made-with-c%2B%2B.svg)       

![GitHub last commit](https://img.shields.io/github/last-commit/Soul-Snatcher/PatternGenerator)

A small project to showcase an animated planetary motion through  visual studio

## Usage

1. Clone this repository using :
 
   Using HTTPS:
      ``` 
     git clone https://github.com/Soul-Snatcher/PatternGenerator.git
      ```
  
    Using SSH :
      ```
      git clone git@github.com:Soul-Snatcher/PatternGenerator.git
      ```      
2.open the cloned folder in Visual Studio

3.Debug and Run

## How it looks like

![image](https://user-images.githubusercontent.com/28761307/148630852-b65f9cb3-e8ce-4bbd-88c5-8eb15ff4c9ab.png)

## YouTube Video
       https://www.youtube.com/watch?v=tJUHXG8A5lw

