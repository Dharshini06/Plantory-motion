//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PattternGenerator.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDB_WRITESMALL                  110
#define IDB_WRITELARGE                  111
#define IDB_MAIN                        112
#define IDB_BUTTONS                     113
#define IDB_FILELARGE                   114
#define IDB_FILESMALL                   115
#define IDR_POPUP_EDIT                  119
#define ID_STATUSBAR_PANE1              120
#define ID_STATUSBAR_PANE2              121
#define IDS_STATUS_PANE1                122
#define IDS_STATUS_PANE2                123
#define IDR_MAINFRAME                   128
#define IDR_MAINFRAME_256               129
#define IDR_PattternGeneratorTYPE       130
#define IDR_PASTE_MENU                  151
#define IDR_WINDOWS_MENU                152
#define ID_VIEW_NAVIGATION              185
#define IDB_NAVIGATION_LARGE            186
#define IDB_NAVIGATION_LARGE_HC         187
#define IDB_PAGES                       188
#define IDB_PAGES_HC                    189
#define IDB_PAGES_SMALL                 190
#define IDB_PAGES_SMALL_HC              191
#define IDR_THEME_MENU                  200
#define ID_SET_STYLE                    201
#define ID_VIEW_APPLOOK_WIN_2000        205
#define ID_VIEW_APPLOOK_OFF_XP          206
#define ID_VIEW_APPLOOK_WIN_XP          207
#define ID_VIEW_APPLOOK_OFF_2003        208
#define ID_VIEW_APPLOOK_VS_2005         209
#define ID_VIEW_APPLOOK_VS_2008         210
#define ID_VIEW_APPLOOK_OFF_2007_BLUE   215
#define ID_VIEW_APPLOOK_OFF_2007_BLACK  216
#define ID_VIEW_APPLOOK_OFF_2007_SILVER 217
#define ID_VIEW_APPLOOK_OFF_2007_AQUA   218
#define ID_VIEW_APPLOOK_WINDOWS_7       219
#define ID_TOOLS_OPTIONS                220
#define ID_VIEW_CAPTION_BAR             221
#define IDB_INFO                        230
#define IDS_CAPTION_BUTTON              231
#define IDS_CAPTION_BUTTON_TIP          232
#define IDS_CAPTION_TEXT                233
#define IDS_CAPTION_IMAGE_TIP           234
#define IDS_CAPTION_IMAGE_TEXT          235
#define IDS_MYCALENDARS                 250
#define IDS_CALENDAR                    251
#define IDS_SHORTCUTS                   252
#define IDS_FOLDERS                     253
#define IDS_OUTLOOKBAR                  258
#define IDS_EDIT_MENU                   306
#define IDR_RIBBON                      307
#define ID_WRITE_PASTEASHYPERLINK       32770
#define ID_BUTTON_START                 32771
#define ID_BUTTON_SUSPEND               32772
#define ID_BUTTON4                      32773
#define ID_RESUME                       32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        310
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
